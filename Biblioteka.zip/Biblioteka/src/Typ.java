public enum Typ {
    HISTORYCZNA,
    KLASYKA,
    FANTASTYKA;

}
